var x = document.getElementsByTagName("a")
for (i = 0; i < x.length; i++) {
  if (x[i].getAttribute("href") == "https://dat1cphbusiness.github.io/content/Java_IntelliJ-File/") {
    x[i].setAttribute("href", "https://dat1cphbusiness.github.io/content/Java_IntelliJ_File/")
  }
}